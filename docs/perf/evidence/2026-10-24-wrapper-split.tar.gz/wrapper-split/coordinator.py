#!/usr/bin/env python3
"""Bounded local HeroParser diagnostic; never builds or changes historical gates.

Run --help for inputs. All protocol/budget/acceptance constants are fixed here.
Only Python's standard library is used. Linux and an existing dotnet are needed.
"""

import argparse
import datetime as dt
import hashlib
import json
import math
import os
from pathlib import Path
import platform
import queue
import re
import select
import shutil
import signal
import subprocess
import sys
import threading
import time
import traceback
import uuid

PROTOCOL = "csv-pipe-isolated-v4-same-cpu"
TRANSPORTS = ("Contiguous", "Segmented128", "Stream4096")
SCENARIOS = ("Plain", "Escaped", "Unicode", "LongEscaped")
PATHS = ("Scan", "Decode", "Generated")
ROWS, PAIRS, MIN_PAIRS = 2000, 30, 10
MIN_MS, PILOT_MS, FINAL_MS, MAX_REPEATS = 100.0, 100.0, 125.0, 65536
WARMUP_SECONDS, WARMUP_LIMIT, CYCLE_LIMIT, RESPONSE_LIMIT = 10.0, 120.0, 600.0, 120.0
SHARED_ENV = ("runtime", "os", "processors", "serverGc", "affinity", "protocol", "pinnedCpu", "allowedCpus")
BASE_FINGERPRINT = SHARED_ENV + ("sourceRef", "parserName", "modelsName", "parserMvid", "modelsMvid", "parserHash", "modelsHash", "consumerHash")
REQUIRED_FILES = ("HeroParser.dll", "CsvPipeABModels.dll", "CsvPipeABProbe.dll", "CsvPipeABProbe.deps.json", "CsvPipeABProbe.runtimeconfig.json")


class Invalid(RuntimeError):
    pass


def require(condition, message):
    if not condition:
        raise Invalid(message)


def now():
    return dt.datetime.now(dt.timezone.utc).isoformat()


def encoded(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False)


def write_json(path, value):
    with Path(path).open("x", encoding="utf-8") as stream:
        json.dump(value, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write("\n")


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def finite(value, positive=False):
    return type(value) in (float, int) and math.isfinite(value) and (value > 0 if positive else value >= 0)


def percentile(values, fraction):
    ordered = sorted(values)
    require(bool(ordered), "Cannot summarize an empty sample.")
    index = (len(ordered) - 1) * fraction
    lower, upper = math.floor(index), math.ceil(index)
    return ordered[lower] + (ordered[upper] - ordered[lower]) * (index - lower)


def directory_manifest(directory):
    require(directory.is_dir(), f"Missing worker directory: {directory}")
    result = {}
    for path in sorted(directory.rglob("*")):
        require(not path.is_symlink(), f"Worker artifacts must not be symlinks: {path}")
        if path.is_file():
            result[path.relative_to(directory).as_posix()] = {"sha256": sha(path), "bytes": path.stat().st_size}
    require(all(name in result for name in REQUIRED_FILES), f"Incomplete frozen worker: {directory}")
    return result


def command_capture(arguments, path, cwd=None, limit=30):
    # Used only for read-only git/runtime context, never for builds or timing.
    with Path(path).open("xb") as stdout, Path(str(path) + ".stderr").open("xb") as stderr:
        process = subprocess.run(arguments, cwd=cwd, stdout=stdout, stderr=stderr, timeout=limit, check=False)
    require(process.returncode == 0, f"Metadata command failed ({process.returncode}): {arguments[0]}")
    return Path(path).read_bytes()


def source_snapshot(directory, source_ref, output, label):
    def git(*arguments, suffix):
        return command_capture(["git", "-C", str(directory), *arguments], output / f"{label}-{suffix}")
    head = git("rev-parse", "HEAD", suffix="head.txt").decode().strip()
    require(head == source_ref, f"{label} source HEAD differs from the supplied ref.")
    status = git("status", "--porcelain=v1", "-z", suffix="status.bin")
    patch = git("diff", "--binary", "HEAD", "--", suffix="changes.patch")
    names = git("ls-files", "-z", "--cached", "--others", "--exclude-standard", suffix="files.bin")
    files = {}
    for raw in sorted(set(names.split(b"\0")) - {b""}):
        name = os.fsdecode(raw)
        path = directory / name
        if path.is_symlink():
            files[name] = {"symlink": os.readlink(path)}
        elif path.is_file():
            files[name] = {"sha256": sha(path), "bytes": path.stat().st_size}
        else:
            files[name] = {"missing": True}
    result = {"directory": str(directory), "sourceRef": head, "dirty": bool(status),
              "patchSha256": hashlib.sha256(patch).hexdigest(), "files": files}
    result["sourceStateSha256"] = hashlib.sha256(encoded(result).encode()).hexdigest()
    write_json(output / f"{label}-source.json", result)
    return result


def host_context(output, label, cpu):
    data = {"utc": now(), "platform": platform.platform(), "uname": list(platform.uname()),
            "python": sys.version, "coordinatorPid": os.getpid(), "pinnedCpu": cpu,
            "coordinatorAllowedCpus": sorted(os.sched_getaffinity(0)), "loadAverage": list(os.getloadavg())}
    paths = ("/proc/cpuinfo", "/proc/loadavg", "/proc/meminfo", "/proc/pressure/cpu", "/proc/self/status",
             f"/sys/devices/system/cpu/cpu{cpu}/topology/core_id",
             f"/sys/devices/system/cpu/cpu{cpu}/topology/physical_package_id",
             f"/sys/devices/system/cpu/cpu{cpu}/topology/thread_siblings_list",
             f"/sys/devices/system/cpu/cpu{cpu}/cpufreq/scaling_governor",
             f"/sys/devices/system/cpu/cpu{cpu}/cpufreq/scaling_cur_freq")
    for name in paths:
        try:
            data[name] = Path(name).read_text()
        except OSError as error:
            data[name] = {"unavailable": str(error)}
    write_json(output / f"{label}-host.json", data)


class Journal:
    def __init__(self, path):
        self.stream = Path(path).open("x", encoding="utf-8", buffering=1)

    def add(self, kind, **values):
        self.stream.write(encoded({"kind": kind, "recordedUtc": now(), **values}) + "\n")

    def close(self):
        self.stream.close()


class Tee:
    def __init__(self, original, path):
        self.original = original
        self.file = Path(path).open("x", encoding="utf-8", buffering=1)

    def write(self, text):
        self.file.write(text)
        self.original.write(text)

    def flush(self):
        self.file.flush()
        self.original.flush()


class Worker:
    """One outstanding request; raw streams are drained even on parse failure."""

    def __init__(self, name, directory, source_ref, cpu, output, launcher, dotnet, deadline):
        self.name, self.directory, self.source_ref = name, directory, source_ref
        self.cpu, self.output, self.launcher, self.dotnet, self.deadline = cpu, output, launcher, dotnet, deadline
        self.process, self.sequence, self.environment = None, 0, None
        self.lines = queue.Queue(maxsize=64)
        self.failure, self.threads, self.logs = None, [], []
        self.requests = None

    def remaining(self, limit=RESPONSE_LIMIT):
        remaining = min(limit, self.deadline - time.monotonic())
        require(remaining > 0, f"{self.name}: fixed cycle deadline reached.")
        return remaining

    def fail_reader(self, message):
        self.failure = self.failure or message
        try:
            self.lines.put_nowait(None)
        except queue.Full:
            pass

    def drain(self, stream, destination, parse):
        pending = b""
        try:
            while True:
                chunk = stream.read(65536)
                if not chunk:
                    break
                destination.write(chunk)
                if not parse or self.failure:
                    continue
                pending += chunk
                while b"\n" in pending:
                    line, pending = pending.split(b"\n", 1)
                    if len(line) > 1024 * 1024:
                        self.fail_reader("Worker stdout line exceeds the 1 MiB protocol bound.")
                        break
                    try:
                        self.lines.put_nowait(line)
                    except queue.Full:
                        self.fail_reader("Worker produced unsolicited stdout faster than requests.")
                        break
                if len(pending) > 1024 * 1024:
                    self.fail_reader("Worker stdout has an oversized unterminated line.")
            if parse:
                if pending and not self.failure:
                    self.fail_reader("Worker stdout ended with an unterminated protocol line.")
                try:
                    self.lines.put_nowait(None)
                except queue.Full:
                    self.fail_reader("Worker stdout queue overflow at EOF.")
        except Exception as error:
            self.fail_reader(f"Raw output capture failed: {error}")

    def start(self):
        environment = os.environ.copy()
        environment.update(HERO_PARSER_WORKER_PROTOCOL=PROTOCOL, HERO_PARSER_WORKER_REF=self.source_ref,
                           HERO_PARSER_WORKER_CPU=str(self.cpu), HERO_PARSER_WORKER_VERIFICATION_MODE="matrix")
        arguments = [sys.executable, str(self.launcher), "--_worker-exec", str(self.cpu), self.dotnet,
                     str(self.directory / "CsvPipeABProbe.dll"), "--rows", str(ROWS)]
        write_json(self.output / f"{self.name}-launch.json", {"argv": arguments, "cwd": str(self.directory),
                   "sourceRef": self.source_ref, "cpu": self.cpu, "protocol": PROTOCOL, "verificationMode": "matrix"})
        self.requests = (self.output / f"{self.name}-requests.ndjson").open("xb", buffering=0)
        stdout = (self.output / f"{self.name}-stdout.ndjson").open("xb", buffering=0)
        stderr = (self.output / f"{self.name}-stderr.log").open("xb", buffering=0)
        self.logs.extend((stdout, stderr))
        self.process = subprocess.Popen(arguments, cwd=self.directory, env=environment, stdin=subprocess.PIPE,
                                        stdout=subprocess.PIPE, stderr=subprocess.PIPE, bufsize=0, start_new_session=True)
        os.set_blocking(self.process.stdin.fileno(), False)
        for stream, destination, parse in ((self.process.stdout, stdout, True), (self.process.stderr, stderr, False)):
            thread = threading.Thread(target=self.drain, args=(stream, destination, parse), daemon=True)
            self.threads.append(thread)
            thread.start()
        self.environment = self.read()
        require(self.environment.get("kind") == "worker-environment" and self.environment.get("pid") == self.process.pid,
                f"{self.name}: worker did not identify its actual process.")

    def read(self):
        require(not self.failure, f"{self.name}: {self.failure}")
        try:
            line = self.lines.get(timeout=self.remaining())
        except queue.Empty as error:
            raise Invalid(f"{self.name}: response timeout; raw logs retained.") from error
        require(not self.failure, f"{self.name}: {self.failure}")
        require(line is not None, f"{self.name}: EOF before a response (exit {self.process.poll()}).")

        def unique(pairs):
            value = {}
            for key, entry in pairs:
                require(key not in value, f"{self.name}: duplicate JSON key {key}.")
                value[key] = entry
            return value

        def reject_constant(value):
            raise Invalid(f"{self.name}: nonfinite JSON constant {value}.")

        response = json.loads(line.decode("utf-8"), object_pairs_hook=unique, parse_constant=reject_constant)
        require(isinstance(response, dict), f"{self.name}: response is not an object.")
        return response

    def request(self, operation, transport=None, repeats=0):
        self.sequence += 1
        message = {"Id": self.sequence, "Operation": operation, "Transport": transport, "Repeats": repeats}
        raw = (encoded(message) + "\n").encode()
        self.requests.write(raw)
        fd = self.process.stdin.fileno()
        write_deadline = time.monotonic() + self.remaining()
        sent = 0
        while sent < len(raw):
            timeout = min(self.remaining(), write_deadline - time.monotonic())
            require(timeout > 0 and select.select([], [fd], [], timeout)[1], f"{self.name}: stdin timeout.")
            try:
                sent += os.write(fd, raw[sent:])
            except BlockingIOError:
                continue
        response = self.read()
        expected = {"verify": "worker-verified", "prepare": "worker-prepared", "batch": "worker-batch", "stop": "worker-stopped"}
        require(response.get("kind") == expected[operation] and type(response.get("Id")) is int and
                response["Id"] == self.sequence and response.get("pid") == self.process.pid,
                f"{self.name}: response/command correlation failed.")
        if operation in ("prepare", "batch"):
            require(response.get("transport") == transport, f"{self.name}: wrong transport.")
        if operation == "batch":
            require(type(response.get("repeats")) is int and response["repeats"] == repeats,
                    f"{self.name}: wrong repeat count.")
        return response

    def stop(self):
        self.request("stop")
        self.process.stdin.close()
        try:
            return_code = self.process.wait(timeout=self.remaining(10))
        except subprocess.TimeoutExpired as error:
            raise Invalid(f"{self.name}: worker failed to exit after stop.") from error
        require(return_code == 0, f"{self.name}: nonzero worker exit {return_code}.")

    def close(self):
        # Signal only this explicitly created process group, never other processes.
        cleanup = {"pid": self.process.pid if self.process else None, "forcedKill": False, "errors": []}
        if self.process:
            if self.process.poll() is None:
                cleanup["forcedKill"] = True
                try:
                    os.killpg(self.process.pid, signal.SIGKILL)
                    self.process.wait(timeout=10)
                except (OSError, subprocess.TimeoutExpired) as error:
                    cleanup["errors"].append(str(error))
            cleanup["exitCode"] = self.process.poll()
            for thread in self.threads:
                thread.join(timeout=2)
            if any(thread.is_alive() for thread in self.threads):
                # A descendant can retain inherited pipes after the leader exits.
                # Signal only the process group created for this worker.
                cleanup["forcedKill"] = True
                try:
                    os.killpg(self.process.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                except OSError as error:
                    cleanup["errors"].append(str(error))
                for thread in self.threads:
                    thread.join(timeout=5)
            cleanup["captureThreadsStillAlive"] = sum(thread.is_alive() for thread in self.threads)
            if cleanup["captureThreadsStillAlive"]:
                cleanup["errors"].append("Output capture did not reach EOF after process cleanup.")
            else:
                for stream in (self.process.stdin, self.process.stdout, self.process.stderr):
                    stream.close()
        if self.failure:
            cleanup["errors"].append(self.failure)
        extras = []
        while True:
            try:
                line = self.lines.get_nowait()
                if line is not None:
                    extras.append(line.decode("utf-8", errors="replace"))
            except queue.Empty:
                break
        if extras:
            cleanup["errors"].append("Unconsumed worker stdout remained; see raw transcript.")
        for log in self.logs:
            if not any(thread.is_alive() for thread in self.threads):
                log.close()
        if self.requests:
            self.requests.close()
        write_json(self.output / f"{self.name}-cleanup.json", cleanup)
        return cleanup


def check_environment(worker, manifest, source_ref, cpu):
    env = worker.environment
    require(env.get("protocol") == PROTOCOL and env.get("verificationMode") == "matrix" and
            env.get("Rows") == ROWS and env.get("sourceRef") == source_ref and
            env.get("pinnedCpu") == str(cpu) and env.get("allowedCpus") == str(cpu), "Worker protocol/source/CPU/settings differ.")
    require(env.get("parserName") == "HeroParser" and env.get("modelsName") == "CsvPipeABModels", "Wrong assembly identities.")
    require(not env.get("jitDisasm") and not env.get("jitDisasmAssemblies"), "Instrumented worker is not timing evidence.")
    require(type(env.get("pid")) is int and env["pid"] > 0 and type(env.get("processors")) is int and
            env["processors"] > 0 and isinstance(env.get("serverGc"), bool) and env.get("runtime") and env.get("os"),
            "Missing worker runtime context.")
    for name in ("parserMvid", "modelsMvid"):
        require(uuid.UUID(env.get(name, "")).int != 0, f"Invalid {name}.")
    for field, file in (("parserHash", "HeroParser.dll"), ("modelsHash", "CsvPipeABModels.dll"), ("consumerHash", "CsvPipeABProbe.dll")):
        require(env.get(field) == manifest[file]["sha256"], f"Worker loaded an unexpected {file}.")


def check_verification(response):
    checks = response.get("checks")
    require(response.get("verificationMode") == "matrix" and response.get("Id") == 1 and
            isinstance(checks, list) and len(checks) == 36, "Full correctness must run in each worker before timing.")
    expected = {(scenario, transport, path) for scenario in SCENARIOS for transport in TRANSPORTS for path in PATHS}
    found = set()
    for item in checks:
        key = (item.get("scenario"), item.get("transport"), item.get("path"))
        require(key in expected and key not in found and type(item.get("Rows")) is int and item["Rows"] == ROWS,
                "Missing, duplicate or invalid correctness case.")
        require(type(item.get("Checksum")) is int and 0 <= item["Checksum"] < 2 ** 64 and
                type(item.get("SplitFields")) is int and item["SplitFields"] >= 0, "Invalid correctness values.")
        require(key[1] != "Segmented128" or key[2] == "Generated" or item["SplitFields"] > 0,
                "Segmented correctness did not exercise split fields.")
        found.add(key)
    require(found == expected, "Incomplete correctness matrix.")


def check_batch(response, minimum=0):
    measurement = response.get("measurement", {})
    milliseconds, allocated = measurement.get("Milliseconds"), measurement.get("AllocatedBytes")
    batch = response.get("batchMs")
    require(finite(milliseconds, positive=True) and finite(allocated) and finite(batch, positive=True), "Invalid batch/allocations.")
    require(abs(batch - milliseconds * response["repeats"]) <= 1e-9, "Batch duration is inconsistent with repeats.")
    require(batch >= minimum, f"Measured batch below fixed minimum {minimum} ms ({batch}); no recalibration/retry allowed.")


def measure_pair(a, b, transport, repeats, candidate_first, journal, stage, index):
    order = (("candidate", b), ("baseline", a)) if candidate_first else (("baseline", a), ("candidate", b))
    result = {}
    for side, worker in order:
        # The second request is sent only after the first complete response.
        response = worker.request("batch", transport, repeats)
        journal.add("batch-response", stage=stage, transport=transport, index=index, side=side, response=response)
        result[side] = response
        check_batch(response)
    return result


def calibrate(a, b, transport, repeats, target, stage, journal):
    attempt = 0
    while True:
        pair = measure_pair(a, b, transport, repeats, attempt % 2 == 0, journal, stage, attempt)
        if min(pair["baseline"]["batchMs"], pair["candidate"]["batchMs"]) >= target:
            journal.add("calibration", scenario="Plain", path="Generated", transport=transport, stage=stage,
                        repeats=repeats, targetBatchMs=target, baselineBatchMs=pair["baseline"]["batchMs"],
                        candidateBatchMs=pair["candidate"]["batchMs"])
            return repeats
        require(repeats < MAX_REPEATS, "Calibration cap reached without meeting target.")
        repeats = min(repeats * 2, MAX_REPEATS)
        attempt += 1


def summarize(transport, samples, repeats):
    require(len(samples) == PAIRS, "Every valid transport requires exactly 30 measured pairs.")
    ratios = [sample["ratio"] for sample in samples]
    allocation_a = [sample["baseline"]["AllocatedBytes"] for sample in samples]
    allocation_b = [sample["candidate"]["AllocatedBytes"] for sample in samples]
    median, p10, p90 = (percentile(ratios, p) for p in (.5, .1, .9))
    a_mean, b_mean = math.fsum(allocation_a) / PAIRS, math.fsum(allocation_b) / PAIRS
    a_median, b_median = percentile(allocation_a, .5), percentile(allocation_b, .5)
    return {"transport": transport, "scenario": "Plain", "path": "Generated", "Rows": ROWS, "Pairs": PAIRS,
            "repeats": repeats, "medianRatio": median, "p10Ratio": p10, "p90Ratio": p90,
            "stable": .95 <= median <= 1.05 and p10 >= .90 and p90 <= 1.10,
            "baselineMedianBytes": a_median, "candidateMedianBytes": b_median,
            "baselineMeanBytes": a_mean, "candidateMeanBytes": b_mean,
            "allocationNoIncrease": b_median <= a_median and b_mean <= a_mean,
            "medianPairedAllocationDelta": percentile([b - a for a, b in zip(allocation_a, allocation_b)], .5),
            "baselineMedianMs": percentile([s["baseline"]["Milliseconds"] for s in samples], .5),
            "candidateMedianMs": percentile([s["candidate"]["Milliseconds"] for s in samples], .5),
            "baselineMinBatchMs": min(s["baselineBatchMs"] for s in samples),
            "candidateMinBatchMs": min(s["candidateBatchMs"] for s in samples),
            "candidateWins": sum(r < 1 for r in ratios),
            "candidateFirstMedian": percentile(ratios[::2], .5), "baselineFirstMedian": percentile(ratios[1::2], .5),
            "firstHalfMedian": percentile(ratios[:15], .5), "secondHalfMedian": percentile(ratios[15:], .5)}


class Coordinator:
    def __init__(self, args, output, cpu, dotnet, manifests):
        self.args, self.output, self.cpu, self.dotnet, self.manifests = args, output, cpu, dotnet, manifests
        self.baseline_fingerprint = None
        self.allowed_cpus = sorted(os.sched_getaffinity(0))

    def frozen(self):
        require(sorted(os.sched_getaffinity(0)) == self.allowed_cpus, "Coordinator CPU permissions changed.")
        for side in ("baseline", "candidate"):
            require(directory_manifest(getattr(self.args, side + "_dir")) == self.manifests[side], f"{side} worker artifacts changed.")

    def cycle(self, name, comparison=False, reverse_launch=False):
        output = self.output / name
        output.mkdir()
        journal = Journal(output / "cycle.ndjson")
        workers, cases = [], []
        result = {"name": name, "kind": "A/B" if comparison else "A/A", "valid": False, "stable": False,
                  "candidateLaunchedFirst": reverse_launch, "cases": cases, "startedUtc": now()}
        try:
            self.frozen()
            host_context(output, "before", self.cpu)
            deadline = time.monotonic() + CYCLE_LIMIT
            b_side = "candidate" if comparison else "baseline"
            a = Worker("a", self.args.baseline_dir, self.args.baseline_ref, self.cpu, output,
                       self.output / "coordinator.py", self.dotnet, deadline)
            b = Worker("b", getattr(self.args, b_side + "_dir"), getattr(self.args, b_side + "_ref"), self.cpu, output,
                       self.output / "coordinator.py", self.dotnet, deadline)
            for worker in ((b, a) if reverse_launch else (a, b)):
                workers.append(worker)
                worker.start()
            journal.add("environment", protocol=PROTOCOL, diagnosticOnly=True, historicalGateValidation=False,
                        baselineRef=self.args.baseline_ref, candidateRef=getattr(self.args, b_side + "_ref"),
                        Rows=ROWS, Pairs=PAIRS, WarmupPairs=MIN_PAIRS, MinSampleMs=MIN_MS,
                        Scenario="Plain", Path="Generated", minWarmupSeconds=WARMUP_SECONDS,
                        calibrationHeadroom=1.25, maxCalibrationRepeats=MAX_REPEATS,
                        baselineWorker=a.environment, candidateWorker=b.environment, candidateLaunchedFirst=reverse_launch)
            check_environment(a, self.manifests["baseline"], self.args.baseline_ref, self.cpu)
            check_environment(b, self.manifests[b_side], getattr(self.args, b_side + "_ref"), self.cpu)
            require(a.environment["pid"] != b.environment["pid"], "Workers must be distinct processes.")
            require(all(a.environment[k] == b.environment[k] for k in SHARED_ENV), "Worker runtime contexts differ.")
            require(all(a.environment[k] == b.environment[k] for k in ("consumerHash", "modelsHash", "modelsMvid")),
                    "Consumer and model modules must remain identical.")
            fingerprint = {key: a.environment[key] for key in BASE_FINGERPRINT}
            if self.baseline_fingerprint is None:
                self.baseline_fingerprint = fingerprint
            require(fingerprint == self.baseline_fingerprint, "Baseline identity/runtime changed between cycles.")
            if not comparison:
                require(all(a.environment[k] == b.environment[k] for k in BASE_FINGERPRINT), "A/A requires identical modules and refs.")
            for worker in (a, b):
                verification = worker.request("verify")
                journal.add("worker-verification", side=worker.name, response=verification)
                check_verification(verification)
            for transport in TRANSPORTS:
                for worker in (a, b):
                    journal.add("prepare-response", side=worker.name, response=worker.request("prepare", transport))
                journal.add("verified", scenario="Plain", path="Generated", transport=transport, Rows=ROWS)
                repeats = calibrate(a, b, transport, 1, PILOT_MS, "pilot", journal)
                started, count = time.monotonic(), 0
                while count < MIN_PAIRS or time.monotonic() - started < WARMUP_SECONDS:
                    require(time.monotonic() - started < WARMUP_LIMIT and count < 4096, "Fixed warmup upper bound reached.")
                    measure_pair(a, b, transport, repeats, count % 2 == 0, journal, "warmup", count)
                    count += 1
                journal.add("warmup", scenario="Plain", path="Generated", transport=transport,
                            pairs=count, elapsedSeconds=time.monotonic() - started)
                repeats = calibrate(a, b, transport, repeats, FINAL_MS, "post-warmup", journal)
                samples = []
                for index in range(PAIRS):
                    pair = measure_pair(a, b, transport, repeats, index % 2 == 0, journal, "measured", index)
                    sample = {"scenario": "Plain", "path": "Generated", "transport": transport, "pair": index,
                              "candidateFirst": index % 2 == 0, "repeats": repeats,
                              "baseline": pair["baseline"]["measurement"], "candidate": pair["candidate"]["measurement"],
                              "baselineBatchMs": pair["baseline"]["batchMs"], "candidateBatchMs": pair["candidate"]["batchMs"],
                              "baselineResponse": pair["baseline"], "candidateResponse": pair["candidate"]}
                    sample["ratio"] = sample["candidate"]["Milliseconds"] / sample["baseline"]["Milliseconds"]
                    journal.add("pair", **sample)  # Preserve undersized pairs before invalidating the cycle.
                    for response in pair.values():
                        check_batch(response, MIN_MS)
                    require(finite(sample["ratio"], positive=True), "Invalid paired ratio.")
                    samples.append(sample)
                summary = summarize(transport, samples, repeats)
                journal.add("summary", **summary)
                cases.append(summary)
            for worker in (a, b):
                worker.stop()
            self.frozen()
            require(len(cases) == 3, "Missing transport summaries.")
            result.update(valid=True, stable=all(case["stable"] for case in cases))
            journal.add("complete", invalidCases=0)
        except Exception as error:
            result["error"] = f"{type(error).__name__}: {error}"
            journal.add("invalid", error=result["error"], traceback=traceback.format_exc())
        except BaseException as error:
            result["error"] = f"Interrupted: {type(error).__name__}"
            journal.add("interrupted", error=result["error"])
            raise
        finally:
            cleanups = []
            for worker in reversed(workers):
                try:
                    cleanups.append(worker.close())
                except Exception as error:
                    cleanups.append({"errors": [f"Cleanup failed: {error}"]})
            result["cleanup"] = cleanups
            if any(item.get("errors") for item in cleanups):
                result.update(valid=False, stable=False)
                result.setdefault("error", "Worker cleanup/output capture failed.")
            result["endedUtc"] = now()
            try:
                host_context(output, "after", self.cpu)
            except Exception as error:
                result.update(valid=False, stable=False, error=f"Host evidence capture failed: {error}")
            journal.add("cycle-result", result=result)
            write_json(output / "result.json", result)
            journal.close()
        print(f"{name}: valid={result['valid']} stable={result['stable']}", flush=True)
        return result


def fixed_plan(args, cpu):
    return {"createdUtc": now(), "purpose": "bounded-local-diagnostic", "historicalGateValidation": False,
            "historicalControlsAndRetryBudgetChanged": False, "protocol": PROTOCOL, "verificationMode": "matrix",
            "fullVerificationCasesPerWorker": 36, "normalAssemblyIdentities": ["HeroParser", "CsvPipeABModels"],
            "cpu": cpu, "rows": ROWS, "pairsPerTransport": PAIRS, "transports": TRANSPORTS,
            "pilotTargetMs": PILOT_MS, "postWarmupTargetMs": FINAL_MS, "minimumMeasuredBatchMs": MIN_MS,
            "warmupMinimumSeconds": WARMUP_SECONDS, "warmupMinimumPairs": MIN_PAIRS, "repeatCap": MAX_REPEATS,
            "initialControls": 3, "initialLaunchOrder": ["A,B", "B,A", "A,B"],
            "abCyclesOnlyIfAllThreeInitialControlsStable": 1, "finalBaselineBaselineControlAfterAb": 1,
            "finalControlRunsEvenIfAbFails": True, "cycleRetries": 0, "measurementOrder": "B,A then A,B, alternating sequentially",
            "aaBounds": {"medianMinimum": .95, "medianMaximum": 1.05, "p10Minimum": .90, "p90Maximum": 1.10},
            "abCriteria": {"medianPairedRatioMaximumAllTransports": 1.0,
                           "medianPairedRatioMaximumContiguousAndStream4096": .97,
                           "allocations": "Both median and mean per-read allocated bytes must not increase on any transport.",
                           "allFourControlsRequired": True},
            "timeoutsSeconds": {"response": RESPONSE_LIMIT, "cycle": CYCLE_LIMIT, "warmupUpperBound": WARMUP_LIMIT, "cleanExit": 10},
            "warmupPairUpperBound": 4096, "noRecalibrationAfterMeasuredPairs": True,
            "baselineRef": args.baseline_ref, "candidateRef": args.candidate_ref,
            "baselineDirectory": str(args.baseline_dir), "candidateDirectory": str(args.candidate_dir),
            "baselineSourceDirectory": str(args.baseline_source_dir), "candidateSourceDirectory": str(args.candidate_source_dir),
            "sourceRefMeaning": "Actual git HEAD; dirty source additionally identified by captured patch and source manifest hashes.",
            "limitations": ["One local A/B cycle does not validate historical CI gates.",
                            "Shared-host scheduling/frequency/background activity may make controls inconclusive.",
                            "Allocation includes background runtime allocation; only this warmed Plain Generated workload is timed.",
                            "Code size is never an acceptance statistic."]}


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    for side in ("baseline", "candidate"):
        parser.add_argument(f"--{side}-dir", type=Path, required=True, help="Existing frozen single-module worker directory")
        parser.add_argument(f"--{side}-ref", required=True, help="Actual 40-hex git HEAD (dirty changes are captured separately)")
        parser.add_argument(f"--{side}-source-dir", type=Path, required=True, help="Source checkout for provenance only")
    parser.add_argument("--output-dir", type=Path, required=True, help="New evidence directory; any existing path is refused")
    parser.add_argument("--cpu", type=int, help="One currently allowed CPU, fixed for the entire series (default: lowest allowed)")
    parser.add_argument("--dotnet", default="dotnet", help="Existing dotnet executable; never used to build")
    parser.add_argument("--provenance", type=Path, action="append", default=[], help="Existing build/patch metadata file to preserve (repeatable)")
    args = parser.parse_args()
    for key in ("baseline_dir", "candidate_dir", "baseline_source_dir", "candidate_source_dir", "output_dir"):
        setattr(args, key, getattr(args, key).resolve())
    output = args.output_dir
    output.mkdir(parents=True, exist_ok=False)
    original_stdout, original_stderr = sys.stdout, sys.stderr
    sys.stdout, sys.stderr = Tee(sys.stdout, output / "coordinator.stdout.log"), Tee(sys.stderr, output / "coordinator.stderr.log")
    summary = {"purpose": "bounded-local-diagnostic", "historicalGateValidation": False, "state": "inconclusive",
               "controls": [], "comparison": None, "finalControl": None, "startedUtc": now()}
    exit_code, cpu = 2, None
    events = Journal(output / "series-events.ndjson")
    prior_handlers = {}
    try:
        for signum in (signal.SIGTERM, signal.SIGINT):
            prior_handlers[signum] = signal.signal(signum, lambda number, frame: (_ for _ in ()).throw(KeyboardInterrupt(f"signal {number}")))
        require(sys.platform == "linux" and hasattr(os, "sched_setaffinity"), "The v4 diagnostic requires Linux CPU affinity.")
        allowed = sorted(os.sched_getaffinity(0))
        cpu = min(allowed) if args.cpu is None else args.cpu
        write_json(output / "fixed-plan.json", fixed_plan(args, cpu))
        shutil.copyfile(__file__, output / "coordinator.py")
        write_json(output / "coordinator-hash.json", {"sha256": sha(output / "coordinator.py"), "argv": sys.argv})
        events.add("fixed-budget-recorded", cpu=cpu)
        require(cpu in allowed, "The requested CPU is not in the coordinator's allowed set.")
        for side in ("baseline", "candidate"):
            require(re.fullmatch(r"[0-9a-f]{40}", getattr(args, side + "_ref")), f"Invalid {side} source ref.")
        require(args.baseline_dir != args.candidate_dir, "Use distinct frozen baseline and candidate directories.")
        dotnet = shutil.which(args.dotnet)
        require(dotnet is not None, "Could not find dotnet.")
        dotnet = str(Path(dotnet).resolve())
        runtime_environment = {key: value for key, value in os.environ.items()
                               if key.upper().startswith(("DOTNET_", "COMPLUS_", "CORECLR_", "COR_", "HERO_PARSER_")) or
                               key in ("PATH", "LANG", "LC_ALL", "LD_LIBRARY_PATH", "LD_PRELOAD", "GLIBC_TUNABLES", "TZ")}
        write_json(output / "runtime-environment.json", {"inherited": runtime_environment, "dotnet": dotnet,
                   "overridesOnly": ["HERO_PARSER_WORKER_PROTOCOL", "HERO_PARSER_WORKER_REF", "HERO_PARSER_WORKER_CPU", "HERO_PARSER_WORKER_VERIFICATION_MODE"]})
        instrumentation = {key: value for key, value in runtime_environment.items() if value and
                           (re.match(r"(?i)^(DOTNET|COMPLUS)_JIT", key) or
                            (key.upper() in ("CORECLR_ENABLE_PROFILING", "COR_ENABLE_PROFILING", "DOTNET_ENABLEEVENTPIPE") and value != "0"))}
        require(not instrumentation, f"Inherited JIT/profiler instrumentation is disallowed: {sorted(instrumentation)}")
        for key, value in runtime_environment.items():
            if re.fullmatch(r"(?i)(DOTNET|COMPLUS)_Tiered(Compilation|PGO)", key):
                require(value.lower() not in ("0", "false"), f"Normal inherited tiering is required; refusing to change {key}.")
        manifests = {side: directory_manifest(getattr(args, side + "_dir")) for side in ("baseline", "candidate")}
        write_json(output / "worker-artifact-manifests.json", manifests)
        for name in set(manifests["baseline"]) | set(manifests["candidate"]):
            if name not in ("HeroParser.dll", "HeroParser.pdb"):
                require(manifests["baseline"].get(name) == manifests["candidate"].get(name), f"Nonparser artifact differs: {name}")
        require(manifests["baseline"]["HeroParser.dll"]["sha256"] != manifests["candidate"]["HeroParser.dll"]["sha256"],
                "A/B requires a distinct candidate parser binary.")
        sources = {side: source_snapshot(getattr(args, side + "_source_dir"), getattr(args, side + "_ref"), output, side)
                   for side in ("baseline", "candidate")}
        require(not sources["baseline"]["dirty"], "The baseline source checkout must be pristine.")
        for index, path in enumerate(args.provenance):
            require(path.is_file(), f"Missing supplied provenance: {path}")
            destination = output / f"supplied-provenance-{index:02d}-{path.name}"
            shutil.copyfile(path, destination)
            write_json(output / f"supplied-provenance-{index:02d}.json", {"source": str(path.resolve()), "sha256": sha(destination)})
        host_context(output, "before-series", cpu)
        command_capture([dotnet, "--info"], output / "dotnet-info.txt")
        coordinator = Coordinator(args, output, cpu, dotnet, manifests)
        print("Fixed budget: 3 fresh A/A controls; only if all are stable, 1 A/B and 1 final baseline/baseline A/A.", flush=True)
        for index in range(1, 4):
            control = coordinator.cycle(f"aa-{index:02d}", reverse_launch=index == 2)
            summary["controls"].append(control)
            events.add("control-complete", result=control)
        initial_stable = all(control["valid"] and control["stable"] for control in summary["controls"])
        if initial_stable:
            summary["comparison"] = coordinator.cycle("ab-01", comparison=True)
            events.add("comparison-complete", result=summary["comparison"])
            summary["finalControl"] = coordinator.cycle("aa-final")
            events.add("final-control-complete", result=summary["finalControl"])
        coordinator.frozen()
        for side in ("baseline", "candidate"):
            final = source_snapshot(getattr(args, side + "_source_dir"), getattr(args, side + "_ref"), output, f"final-{side}")
            require(final["sourceStateSha256"] == sources[side]["sourceStateSha256"], f"{side} source provenance changed during the series.")
        if not initial_stable:
            summary["reason"] = "One or more of the three fixed A/A controls were invalid or unstable; A/B was not attempted. Inconclusive."
        elif not (summary["finalControl"]["valid"] and summary["finalControl"]["stable"]):
            summary["reason"] = "The final fixed A/A was invalid or unstable; the A/B observation is inconclusive."
        elif not summary["comparison"]["valid"]:
            summary["reason"] = "The single A/B cycle was invalid. Inconclusive; no retry was attempted."
        else:
            cases = summary["comparison"]["cases"]
            qualified = all(case["medianRatio"] <= 1.0 and case["allocationNoIncrease"] and
                            (case["transport"] == "Segmented128" or case["medianRatio"] <= .97) for case in cases)
            summary["state"] = "local-gain-criteria-met" if qualified else "local-gain-criteria-not-met"
            summary["reason"] = ("All four controls were stable and the single local A/B met the fixed timing/allocation criteria."
                                 if qualified else "All four controls were stable, but the single local A/B did not meet every fixed gain/allocation criterion.")
            exit_code = 0 if qualified else 3
        summary["historicalGateConclusion"] = "Historical failed controls and their retry budget are unchanged; this local diagnostic does not validate those gates."
    except BaseException as error:
        summary.update(state="inconclusive", reason=f"{type(error).__name__}: {error}")
        events.add("series-error", error=summary["reason"], traceback=traceback.format_exc())
        traceback.print_exc()
        exit_code = 130 if isinstance(error, KeyboardInterrupt) else 2
    finally:
        summary["endedUtc"] = now()
        summary["exitCode"] = exit_code
        if cpu is not None:
            try:
                host_context(output, "after-series", cpu)
            except Exception as error:
                summary.update(state="inconclusive", reason=f"Final host evidence capture failed: {error}", exitCode=2)
                exit_code = 2
        events.add("series-result", summary=summary)
        write_json(output / "series-summary.json", summary)
        print(f"{summary['state']}: {summary.get('reason', '')}", flush=True)
        events.close()
        for signum, previous in prior_handlers.items():
            signal.signal(signum, previous)
        sys.stdout.flush()
        sys.stderr.flush()
        sys.stdout.file.close()
        sys.stderr.file.close()
        sys.stdout, sys.stderr = original_stdout, original_stderr
    return exit_code


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "--_worker-exec":
        # No preexec_fn: this is a fresh interpreter, safe even when the parent
        # already has reader threads. Affinity is inherited by the CLR at exec.
        selected_cpu = int(sys.argv[2])
        os.sched_setaffinity(0, {selected_cpu})
        require(os.sched_getaffinity(0) == {selected_cpu}, "Unable to establish the requested startup affinity.")
        os.execv(sys.argv[3], sys.argv[3:])
    sys.exit(main())
